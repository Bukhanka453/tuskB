import { defineConfig } from '@playwright/test';
import config from './playwright.shared';

export default defineConfig(config);
