import { existsSync, readdirSync, statSync } from 'node:fs';
import { fileURLToPath } from 'url';
import { join } from 'node:path';

if (process.env.NO_COLOR && !process.env.CI) delete process.env.NO_COLOR;

const getAppMode = () =>
  process.env.APP_MODE === 'reference' ? 'reference' : 'target';

const getPort = () => Number(process.env.PW_PORT || '4173');

const getWebServerCommand = () =>
  getAppMode() === 'reference'
    ? (process.env.PW_WEB_SERVER_COMMAND_REFERENCE ?? 'npm run dev:e2e:reference')
    : (process.env.PW_WEB_SERVER_COMMAND_TARGET ?? 'npm run dev:e2e:target');

const getJsonReporter = () =>
  process.env.PW_JSON_OUTPUT
    ? [['json', { outputFile: process.env.PW_JSON_OUTPUT }]]
    : [];

const getScreenshotDiffReporter = () => {
  const dir = process.env.PW_SCREENSHOT_DIFFS_DIR ?? 'screenshot-diffs';
  return [[
    fileURLToPath(new URL('./tests/screenshot-diff-reporter.mjs', import.meta.url)),
    { outputDir: dir },
  ]];
};

const getReporter = () => [[process.env.CI ? 'dot' : 'line'], ...getJsonReporter(), ...getScreenshotDiffReporter()];

const getSnapshotPathTemplate = () =>
  process.env.PW_SNAPSHOT_PATH_TEMPLATE ?? '{testFileDir}/e2e.screenshots/{arg}{ext}';

const hasE2ETests = dir => {
  if (!existsSync(dir)) return false;
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    const stat = statSync(full);
    if (stat.isDirectory()) {
      if (hasE2ETests(full)) return true;
      continue;
    }
    if (stat.isFile() && name.endsWith('.e2e.ts')) return true;
  }
  return false;
};

const semanticPlaywrightConfig = {
  testDir: '.',
  testMatch: ['tests/**/*.e2e.ts'],
  use: {
    headless: true,
    viewport: { width: 1280, height: 720 },
    locale: 'en-US',
    timezoneId: 'UTC',
    colorScheme: 'light',
  },
  expect: {
    toHaveScreenshot: {
      animations: 'disabled',
      pathTemplate: getSnapshotPathTemplate(),
      scale: 'css',
      stylePath: fileURLToPath(new URL('./tests/screenshot.css', import.meta.url)),
    },
  },
};

const port = getPort();
const webServerCommand = getWebServerCommand();

const config = {
  ...semanticPlaywrightConfig,
  reporter: getReporter(),
  use: {
    ...semanticPlaywrightConfig.use,
    baseURL: process.env.PW_BASE_URL || `http://127.0.0.1:${port}`,
  },
};

if (webServerCommand) {
  config.webServer = {
    command: webServerCommand,
    port,
    reuseExistingServer: !process.env.CI,
    timeout: 120_000,
  };
}

if (!hasE2ETests('tests'))
  delete config.webServer;

export default config;
