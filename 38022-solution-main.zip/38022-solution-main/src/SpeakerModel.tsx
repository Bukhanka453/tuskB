import React, { useId } from 'react';
import { speakerDesign, surfacePoint } from './fixtures';
import {
  SCENE_SCALE,
  isAnchorVisible,
  modelSilhouette,
  projectPoint,
  screenBasis,
  viewDirection,
} from './projection';
import { buildWeave } from './weave';
import type { Camera, ModelShape, Size, Vec2, Vec3 } from './types';

export interface SpeakerModelProps {
  shape: ModelShape;
  camera: Camera;
  viewport: Size;
  /** Идентификатор варианта материала корпуса; неизвестные сводятся к графиту. */
  variant?: string;
}

/** Цветовая схема материала корпуса. */
interface MaterialTheme {
  /** Базовая заливка ткани. */
  body: string;
  /** Светлые нити переплетения. */
  weaveLight: string;
  /** Тёмные нити переплетения. */
  weaveDark: string;
  /** Стеклянная верхняя панель: градиент сверху вниз. */
  domeTop: string;
  domeBottom: string;
  /** Кромка панели. */
  domeRim: string;
  /** Плинт основания: градиент сверху вниз. */
  bandTop: string;
  bandBottom: string;
  /** Плоское днище и его кромка. */
  base: string;
  baseRim: string;
  /** Шов ткани. */
  seam: string;
  /** Теневая сторона корпуса: цвет и сила затемнения. */
  shadeColor: string;
  shadeOpacity: number;
  /** Затемнение нижней части корпуса. */
  ambientBottom: number;
  /** Обводка силуэта. */
  outline: string;
}

const MATERIALS: Record<string, MaterialTheme> = {
  graphite: {
    body: '#414b5a',
    weaveLight: 'rgba(255,255,255,0.05)',
    weaveDark: 'rgba(0,0,0,0.14)',
    domeTop: '#3b4656',
    domeBottom: '#141920',
    domeRim: 'rgba(150,175,215,0.28)',
    bandTop: '#2a303a',
    bandBottom: '#171b21',
    base: '#14171c',
    baseRim: 'rgba(255,255,255,0.09)',
    seam: 'rgba(0,0,0,0.38)',
    shadeColor: '#04070b',
    shadeOpacity: 0.62,
    ambientBottom: 0.3,
    outline: 'rgba(160,180,210,0.16)',
  },
  ivory: {
    body: '#d8d1c0',
    weaveLight: 'rgba(255,255,255,0.4)',
    weaveDark: 'rgba(122,108,84,0.16)',
    domeTop: '#ece8dd',
    domeBottom: '#b3ac9b',
    domeRim: 'rgba(255,255,255,0.55)',
    bandTop: '#c6bfae',
    bandBottom: '#a29b89',
    base: '#b0a996',
    baseRim: 'rgba(0,0,0,0.12)',
    seam: 'rgba(96,86,66,0.42)',
    shadeColor: '#4a4438',
    shadeOpacity: 0.38,
    ambientBottom: 0.16,
    outline: 'rgba(96,86,66,0.3)',
  },
};

const materialTheme = (variant: string | undefined): MaterialTheme =>
  MATERIALS[variant ?? 'graphite'] ?? MATERIALS.graphite;

/** Направление мирового света: неподвижно, блик «живёт» на корпусе при вращении. */
const LIGHT_DIRECTION: Vec3 = [-0.45, 0.72, 0.5];

const toRadians = (deg: number): number => (deg * Math.PI) / 180;
const toDegrees = (rad: number): number => (rad * 180) / Math.PI;

const dot = (a: Vec3, b: Vec3): number => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

const cross = (a: Vec3, b: Vec3): Vec3 => [
  a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2],
  a[0] * b[1] - a[1] * b[0],
];

const unit = (a: Vec3): Vec3 => {
  const length = Math.hypot(a[0], a[1], a[2]) || 1;
  return [a[0] / length, a[1] / length, a[2] / length];
};

/** Истинная нормаль эллипсоида в точке поверхности (для визуализации). */
const trueNormal = (shape: ModelShape, point: Vec3): Vec3 =>
  unit([
    (point[0] - shape.center[0]) / shape.radii[0] ** 2,
    (point[1] - shape.center[1]) / shape.radii[1] ** 2,
    (point[2] - shape.center[2]) / shape.radii[2] ** 2,
  ]);

const pathFromPoints = (points: readonly Vec2[], close: boolean): string =>
  points
    .map((p, index) => `${index === 0 ? 'M' : 'L'}${p.x.toFixed(2)} ${p.y.toFixed(2)}`)
    .join(' ') + (close ? ' Z' : '');

interface VisibleArc {
  /** Азимут первой точки видимой дуги параллели. */
  start: number;
  /** Азимут последней точки (может быть больше 360 — дуга через ноль). */
  end: number;
}

/**
 * Видимая дуга параллели на заданной высоте.
 * Ищется аналитически: параллель касается силуэта там, где нормаль
 * перпендикулярна направлению взгляда — уравнение A·cos(az) + B·sin(az) + C = 0.
 */
const parallelVisibleArc = (
  shape: ModelShape,
  elevation: number,
  camera: Camera,
): VisibleArc | 'full' | 'hidden' => {
  const e = toRadians(elevation);
  const v = viewDirection(camera);
  const a = (Math.cos(e) * v[0]) / shape.radii[0];
  const b = (Math.cos(e) * v[2]) / shape.radii[2];
  const c = (Math.sin(e) * v[1]) / shape.radii[1];
  const r = Math.hypot(a, b);
  if (r < 1e-9) return 'hidden';
  const ratio = -c / r;
  if (ratio > 1) return 'full';
  if (ratio < -1) return 'hidden';
  const delta = Math.atan2(b, a);
  const gamma = Math.acos(Math.max(-1, Math.min(1, ratio)));
  return {
    start: toDegrees(delta + gamma),
    end: toDegrees(delta - gamma + 2 * Math.PI),
  };
};

interface Silhouette {
  center: Vec2;
  radiusX: number;
  radiusY: number;
}

/**
 * Силуэтная кривая эллипсоида в 3D: предобраз на единичной сфере — большой
 * круг, перпендикулярный D⁻¹·v. Возвращает точку кривой по углу параметра.
 */
const silhouetteSampler = (shape: ModelShape, camera: Camera) => {
  const v = viewDirection(camera);
  const w = unit([v[0] / shape.radii[0], v[1] / shape.radii[1], v[2] / shape.radii[2]]);
  const reference: Vec3 = Math.abs(w[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
  const e1 = unit(cross(w, reference));
  const e2 = cross(w, e1);

  return {
    /** Точка силуэта в 3D по углу параметра (радианы). */
    at(theta: number): Vec3 {
      const s: Vec3 = [
        Math.cos(theta) * e1[0] + Math.sin(theta) * e2[0],
        Math.cos(theta) * e1[1] + Math.sin(theta) * e2[1],
        Math.cos(theta) * e1[2] + Math.sin(theta) * e2[2],
      ];
      return [
        shape.center[0] + shape.radii[0] * s[0],
        shape.center[1] + shape.radii[1] * s[1],
        shape.center[2] + shape.radii[2] * s[2],
      ];
    },
    /** Угол параметра для точки поверхности, лежащей на силуэте. */
    thetaOf(point: Vec3): number {
      const s: Vec3 = [
        (point[0] - shape.center[0]) / shape.radii[0],
        (point[1] - shape.center[1]) / shape.radii[1],
        (point[2] - shape.center[2]) / shape.radii[2],
      ];
      return Math.atan2(dot(s, e2), dot(s, e1));
    },
  };
};

/** Высота точки поверхности в градусах относительно экватора. */
const elevationOf = (shape: ModelShape, point: Vec3): number =>
  toDegrees(
    Math.asin(
      Math.max(-1, Math.min(1, (point[1] - shape.center[1]) / shape.radii[1])),
    ),
  );

interface BodyOutline {
  d: string;
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
}

/**
 * Контур усечённого корпуса: видимая дуга параллели на срезе основания,
 * замкнутая дугой силуэтной кривой, проходящей выше среза. Возвращает путь
 * и его экранные границы (для тени и градиентов).
 */
const buildBodyOutline = (
  shape: ModelShape,
  cutElevation: number,
  camera: Camera,
  viewport: Size,
  silhouette: Silhouette,
): BodyOutline => {
  const { center, radiusX, radiusY } = silhouette;
  const arc = parallelVisibleArc(shape, cutElevation, camera);

  let points: Vec2[];

  if (arc === 'full' || arc === 'hidden') {
    // Срез не образует видимую кромку: контур совпадает с силуэтом эллипсоида.
    points = [];
    for (let i = 0; i < 120; i += 1) {
      const angle = (i / 120) * 2 * Math.PI;
      points.push({
        x: center.x + radiusX * Math.cos(angle),
        y: center.y + radiusY * Math.sin(angle),
      });
    }
  } else {
    // Нижняя кромка: видимая дуга параллели на срезе (точные касательные концы).
    const { start, end } = arc;
    const step = Math.max(1, (end - start) / 72);
    const rim: Vec2[] = [];
    for (let az = start; az <= end + 1e-6; az += step) {
      rim.push(projectPoint(surfacePoint(shape, az % 360, cutElevation), camera, viewport).screen);
    }

    // Боковой и верхний контур: дуга силуэтной кривой выше среза.
    const sampler = silhouetteSampler(shape, camera);
    const tStart = surfacePoint(shape, start % 360, cutElevation);
    const tEnd = surfacePoint(shape, end % 360, cutElevation);
    const thetaStart = sampler.thetaOf(tStart);
    const thetaEnd = sampler.thetaOf(tEnd);

    let sweepEnd = thetaStart;
    while (sweepEnd <= thetaEnd) sweepEnd += 2 * Math.PI;
    const midElevation = elevationOf(shape, sampler.at((thetaEnd + sweepEnd) / 2));
    const sweep = midElevation > cutElevation ? sweepEnd : sweepEnd - 2 * Math.PI;

    const side: Vec2[] = [];
    const segments = 96;
    for (let i = 1; i < segments; i += 1) {
      const theta = thetaEnd + ((sweep - thetaEnd) * i) / segments;
      side.push(projectPoint(sampler.at(theta), camera, viewport).screen);
    }

    points = [...rim, ...side];
  }

  const xs = points.map(p => p.x);
  const ys = points.map(p => p.y);
  return {
    d: pathFromPoints(points, true),
    minX: Math.min(...xs),
    maxX: Math.max(...xs),
    minY: Math.min(...ys),
    maxY: Math.max(...ys),
  };
};

/**
 * Контур стеклянной верхней панели: видимая дуга параллели на срезе панели,
 * замкнутая дугой силуэта корпуса. Возвращает `null`, если панель не видна.
 */
const buildDomePath = (
  shape: ModelShape,
  capElevation: number,
  camera: Camera,
  viewport: Size,
  silhouette: Silhouette,
): string | null => {
  const parallel = (azimuth: number): Vec2 =>
    projectPoint(surfacePoint(shape, azimuth, capElevation), camera, viewport).screen;

  const arc = parallelVisibleArc(shape, capElevation, camera);

  if (arc === 'hidden') return null;

  if (arc === 'full') {
    const points: Vec2[] = [];
    for (let az = 0; az <= 360; az += 3) points.push(parallel(az));
    return pathFromPoints(points, true);
  }

  const { start, end } = arc;
  const step = Math.max(1, (end - start) / 80);
  const front: Vec2[] = [];
  for (let az = start; az <= end + 1e-6; az += step) {
    front.push(parallel(az % 360));
  }

  const tStart = front[0];
  const tEnd = front[front.length - 1];
  const { center, radiusX, radiusY } = silhouette;
  const angleOf = (p: Vec2): number =>
    Math.atan2((p.y - center.y) / radiusY, (p.x - center.x) / radiusX);
  const arcPoint = (angle: number): Vec2 => ({
    x: center.x + radiusX * Math.cos(angle),
    y: center.y + radiusY * Math.sin(angle),
  });

  // Дуга силуэта от tEnd обратно к tStart по верхней (дальней от центра) стороне.
  const aEnd = angleOf(tEnd);
  let aStart = angleOf(tStart);
  while (aStart <= aEnd) aStart += 2 * Math.PI;

  const chordMid = { x: (tStart.x + tEnd.x) / 2, y: (tStart.y + tEnd.y) / 2 };
  const midOnArc = arcPoint((aEnd + aStart) / 2);
  const outward =
    (midOnArc.x - chordMid.x) * (chordMid.x - center.x) +
    (midOnArc.y - chordMid.y) * (chordMid.y - center.y);

  const sweep = outward > 0 ? aStart : aStart - 2 * Math.PI;
  const back: Vec2[] = [];
  const segments = 48;
  for (let i = 1; i < segments; i += 1) {
    back.push(arcPoint(aEnd + ((sweep - aEnd) * i) / segments));
  }

  return pathFromPoints([...front, ...back], true);
};

/**
 * Полоса плинта вдоль нижнего края корпуса: лента между параллелями
 * `fromElevation` (срез) и `toElevation` на видимой стороне.
 */
const buildBandPath = (
  shape: ModelShape,
  fromElevation: number,
  toElevation: number,
  camera: Camera,
  viewport: Size,
): string | null => {
  const arc = parallelVisibleArc(shape, fromElevation, camera);

  if (arc === 'hidden') return null;

  if (arc === 'full') {
    const lower: Vec2[] = [];
    const upper: Vec2[] = [];
    for (let az = 0; az <= 360; az += 3) {
      lower.push(projectPoint(surfacePoint(shape, az, fromElevation), camera, viewport).screen);
      upper.push(projectPoint(surfacePoint(shape, az, toElevation), camera, viewport).screen);
    }
    return `${pathFromPoints(upper, true)} ${pathFromPoints(lower.reverse(), true)}`;
  }

  const { start, end } = arc;
  const step = Math.max(1, (end - start) / 60);
  const lower: Vec2[] = [];
  const upper: Vec2[] = [];
  for (let az = start; az <= end + 1e-6; az += step) {
    lower.push(projectPoint(surfacePoint(shape, az % 360, fromElevation), camera, viewport).screen);
    upper.push(projectPoint(surfacePoint(shape, az % 360, toElevation), camera, viewport).screen);
  }

  return pathFromPoints([...upper, ...lower.reverse()], true);
};

/** Проекция плоского днища (полная параллель на срезе основания). */
const buildBaseDiscPath = (
  shape: ModelShape,
  cutElevation: number,
  camera: Camera,
  viewport: Size,
): string => {
  const points: Vec2[] = [];
  for (let az = 0; az <= 360; az += 3) {
    points.push(projectPoint(surfacePoint(shape, az, cutElevation), camera, viewport).screen);
  }
  return pathFromPoints(points, true);
};

/** Видимая часть параллели (кольцо подсветки) ломаной линией. */
const buildRingPath = (
  shape: ModelShape,
  elevation: number,
  camera: Camera,
  viewport: Size,
): string | null => {
  const points: Vec2[] = [];
  for (let az = camera.azimuth - 180; az <= camera.azimuth + 180; az += 2) {
    const world = surfacePoint(shape, az, elevation);
    if (!isAnchorVisible(world, shape, camera)) continue;
    points.push(projectPoint(world, camera, viewport).screen);
  }
  return points.length > 1 ? pathFromPoints(points, false) : null;
};

/** Видимая часть меридиана (шов ткани) ломаной линией. */
const buildSeamPath = (
  shape: ModelShape,
  azimuth: number,
  fromElevation: number,
  toElevation: number,
  camera: Camera,
  viewport: Size,
): string | null => {
  const points: Vec2[] = [];
  for (let el = fromElevation; el <= toElevation; el += 2) {
    const world = surfacePoint(shape, azimuth, el);
    if (!isAnchorVisible(world, shape, camera)) continue;
    points.push(projectPoint(world, camera, viewport).screen);
  }
  return points.length > 1 ? pathFromPoints(points, false) : null;
};

interface FeatureFrame {
  x: number;
  y: number;
  /** Угол наклона меридиана поверхности на экране. */
  angle: number;
  /** Сжатие элемента вдоль меридиана из-за ракурса. */
  squash: number;
  visible: boolean;
}

/** Рамка для отрисовки небольшого элемента на поверхности с учётом наклона. */
const featureFrame = (
  shape: ModelShape,
  azimuth: number,
  elevation: number,
  camera: Camera,
  viewport: Size,
): FeatureFrame => {
  const world = surfacePoint(shape, azimuth, elevation);
  const { screen } = projectPoint(world, camera, viewport);
  const normal = trueNormal(shape, world);
  const squash = Math.max(0.3, Math.abs(dot(normal, viewDirection(camera))));

  const a = toRadians(azimuth);
  const e = toRadians(elevation);
  const meridian: Vec3 = [
    -shape.radii[0] * Math.sin(e) * Math.cos(a),
    shape.radii[1] * Math.cos(e),
    -shape.radii[2] * Math.sin(e) * Math.sin(a),
  ];
  const { right, up } = screenBasis(camera);
  const angle = toDegrees(Math.atan2(-dot(meridian, up), dot(meridian, right)));

  return {
    x: screen.x,
    y: screen.y,
    angle,
    squash,
    visible: isAnchorVisible(world, shape, camera),
  };
};

const featureTransform = (frame: FeatureFrame): string =>
  `translate(${frame.x.toFixed(2)} ${frame.y.toFixed(2)}) rotate(${frame.angle.toFixed(
    2,
  )}) scale(1 ${frame.squash.toFixed(3)})`;

/**
 * Реалистичная 3D-модель умной колонки: тканевый корпус с плоским основанием,
 * стеклянная верхняя панель с кольцом подсветки, микрофоны, твитер, кнопка
 * и разъём. Все элементы живут на поверхности эллипсоида и освещены
 * неподвижным мировым светом, поэтому при вращении камеры корпус ведёт себя
 * как объёмный объект, устойчиво стоящий на ровной поверхности.
 */
export const SpeakerModel = ({ shape, camera, viewport, variant }: SpeakerModelProps) => {
  const silhouette = modelSilhouette(shape, camera, viewport);
  const { center, radiusX, radiusY } = silhouette;
  const maxRadius = Math.max(radiusX, radiusY);
  const design = speakerDesign;
  const theme = materialTheme(variant);

  // Уникальные id градиентов: на странице может быть несколько сцен одновременно.
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const ids = {
    key: `speaker-key-${uid}`,
    shade: `speaker-shade-${uid}`,
    ambient: `speaker-ambient-${uid}`,
    dome: `speaker-dome-${uid}`,
    band: `speaker-band-${uid}`,
    tweeter: `speaker-tweeter-${uid}`,
    blur: `speaker-blur-${uid}`,
    blurSmall: `speaker-blur-small-${uid}`,
    clip: `speaker-clip-${uid}`,
    domeClip: `speaker-dome-clip-${uid}`,
  } as const;

  // Блик: точка поверхности, чья нормаль совпадает с направлением света.
  const light = unit(LIGHT_DIRECTION);
  const towardLight = unit([
    shape.radii[0] * light[0],
    shape.radii[1] * light[1],
    shape.radii[2] * light[2],
  ]);
  const highlightWorld: Vec3 = [
    shape.center[0] + shape.radii[0] * towardLight[0],
    shape.center[1] + shape.radii[1] * towardLight[1],
    shape.center[2] + shape.radii[2] * towardLight[2],
  ];
  const highlight = projectPoint(highlightWorld, camera, viewport).screen;
  const shade = { x: 2 * center.x - highlight.x, y: 2 * center.y - highlight.y };

  const body = buildBodyOutline(shape, design.baseCutElevation, camera, viewport, {
    center,
    radiusX,
    radiusY,
  });
  const bandPath = buildBandPath(
    shape,
    design.baseBand.fromElevation,
    design.baseBand.toElevation,
    camera,
    viewport,
  );
  const domePath = buildDomePath(shape, design.domeElevation, camera, viewport, {
    center,
    radiusX,
    radiusY,
  });
  const ringPath = buildRingPath(shape, design.lightRingElevation, camera, viewport);
  const seamPath = buildSeamPath(
    shape,
    design.fabricSeam.azimuth,
    design.fabricSeam.fromElevation,
    design.fabricSeam.toElevation,
    camera,
    viewport,
  );

  // Плоское днище видно только при взгляде снизу.
  const baseDiscPath =
    camera.elevation < 0
      ? buildBaseDiscPath(shape, design.baseCutElevation, camera, viewport)
      : null;

  const tweeter = featureFrame(
    shape,
    design.tweeter.azimuth,
    design.tweeter.elevation,
    camera,
    viewport,
  );
  const button = featureFrame(
    shape,
    design.muteButton.azimuth,
    design.muteButton.elevation,
    camera,
    viewport,
  );
  const port = featureFrame(
    shape,
    design.powerPort.azimuth,
    design.powerPort.elevation,
    camera,
    viewport,
  );
  const mics = design.micArray.azimuths.map(azimuth =>
    featureFrame(shape, azimuth, design.micArray.elevation, camera, viewport),
  );

  const tweeterRadius = design.tweeter.radius * SCENE_SCALE;
  const buttonRadius = design.muteButton.radius * SCENE_SCALE;
  const portWidth = design.powerPort.width * SCENE_SCALE;
  const portHeight = design.powerPort.height * SCENE_SCALE;

  return (
    <g className="speaker" data-material={variant ?? 'graphite'}>
      <defs>
        <radialGradient
          id={ids.key}
          gradientUnits="userSpaceOnUse"
          cx={highlight.x}
          cy={highlight.y}
          r={maxRadius * 1.5}
        >
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.3" />
          <stop offset="0.45" stopColor="#ffffff" stopOpacity="0.07" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </radialGradient>
        <radialGradient
          id={ids.shade}
          gradientUnits="userSpaceOnUse"
          cx={shade.x}
          cy={shade.y}
          r={maxRadius * 1.5}
        >
          <stop offset="0" stopColor={theme.shadeColor} stopOpacity={theme.shadeOpacity} />
          <stop offset="0.72" stopColor={theme.shadeColor} stopOpacity="0" />
        </radialGradient>
        <linearGradient
          id={ids.ambient}
          gradientUnits="userSpaceOnUse"
          x1={0}
          y1={body.minY}
          x2={0}
          y2={body.maxY}
        >
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.07" />
          <stop offset="0.45" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="1" stopColor="#000000" stopOpacity={theme.ambientBottom} />
        </linearGradient>
        <linearGradient
          id={ids.dome}
          gradientUnits="userSpaceOnUse"
          x1={0}
          y1={center.y - radiusY}
          x2={0}
          y2={center.y}
        >
          <stop offset="0" stopColor={theme.domeTop} />
          <stop offset="1" stopColor={theme.domeBottom} />
        </linearGradient>
        <linearGradient
          id={ids.band}
          gradientUnits="userSpaceOnUse"
          x1={0}
          y1={body.maxY - 40}
          x2={0}
          y2={body.maxY}
        >
          <stop offset="0" stopColor={theme.bandTop} />
          <stop offset="1" stopColor={theme.bandBottom} />
        </linearGradient>
        <radialGradient id={ids.tweeter} cx="0.38" cy="0.34" r="0.85">
          <stop offset="0" stopColor="#77859a" />
          <stop offset="0.55" stopColor="#39424f" />
          <stop offset="1" stopColor="#12161c" />
        </radialGradient>
        <filter id={ids.blur} x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="6" />
        </filter>
        <filter id={ids.blurSmall} x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="2.5" />
        </filter>
        <clipPath id={ids.clip}>
          <path d={body.d} />
        </clipPath>
        {domePath && (
          <clipPath id={ids.domeClip}>
            <path d={domePath} />
          </clipPath>
        )}
      </defs>

      <ellipse
        className="speaker-shadow"
        filter={`url(#${ids.blur})`}
        cx={(body.minX + body.maxX) / 2}
        cy={body.maxY + 9}
        rx={((body.maxX - body.minX) / 2) * 0.86}
        ry={11}
      />

      <g clipPath={`url(#${ids.clip})`}>
        <path
          className="speaker-body"
          data-testid="model-body"
          d={body.d}
          fill={theme.body}
        />
        <g className="speaker-weave" data-testid="model-weave">
          {buildWeave(shape, camera, viewport).map((line, index) => (
            <polyline
              key={`${line.kind}-${line.at}-${index}`}
              className={line.kind === 'meridian' ? 'weave-warp' : 'weave-weft'}
              data-weave-kind={line.kind}
              data-weave-at={line.at}
              stroke={line.kind === 'meridian' ? theme.weaveLight : theme.weaveDark}
              points={line.points.map(point => `${point.x},${point.y}`).join(' ')}
            />
          ))}
        </g>
        <path d={body.d} fill={`url(#${ids.key})`} />
        <path d={body.d} fill={`url(#${ids.shade})`} />
        <path d={body.d} fill={`url(#${ids.ambient})`} />

        {bandPath && <path className="speaker-band" d={bandPath} fill={`url(#${ids.band})`} />}

        {baseDiscPath && (
          <g className="speaker-base">
            <path d={baseDiscPath} fill={theme.base} />
            <path d={baseDiscPath} fill="none" stroke={theme.baseRim} strokeWidth={1} />
          </g>
        )}

        {domePath && (
          <g className="speaker-dome">
            <path d={domePath} fill={`url(#${ids.dome})`} />
            <ellipse
              cx={highlight.x}
              cy={highlight.y}
              rx={radiusX * 0.38}
              ry={radiusY * 0.14}
              fill="#ffffff"
              opacity="0.16"
              filter={`url(#${ids.blurSmall})`}
              clipPath={`url(#${ids.domeClip})`}
            />
            <path d={domePath} fill="none" stroke={theme.domeRim} strokeWidth={1} />
          </g>
        )}

        {seamPath && <path className="speaker-seam" stroke={theme.seam} d={seamPath} />}

        {ringPath && (
          <g className="speaker-ring">
            <path d={ringPath} className="speaker-ring-glow" />
            <path d={ringPath} className="speaker-ring-core" />
          </g>
        )}

        {tweeter.visible && (
          <g className="speaker-tweeter" transform={featureTransform(tweeter)}>
            <circle r={tweeterRadius} fill={`url(#${ids.tweeter})`} stroke="#5b6879" strokeWidth={1.2} />
            <circle r={tweeterRadius * 0.62} fill="#12161c" />
            <circle r={tweeterRadius * 0.26} fill="#2d3641" />
            <circle
              cx={-tweeterRadius * 0.3}
              cy={-tweeterRadius * 0.34}
              r={tweeterRadius * 0.14}
              fill="rgba(255,255,255,0.55)"
            />
          </g>
        )}

        {mics.map(
          (mic, index) =>
            mic.visible && (
              <g key={index} transform={featureTransform(mic)}>
                <circle
                  r={design.micArray.radius * SCENE_SCALE}
                  fill="#0b0e12"
                  stroke="#47525f"
                  strokeWidth={0.7}
                />
              </g>
            ),
        )}

        {button.visible && (
          <g className="speaker-mute-button" transform={featureTransform(button)}>
            <circle r={buttonRadius} fill="#1c232d" stroke="#4d5a6c" strokeWidth={1.2} />
            <g stroke="#a9bdd4" strokeWidth={1.3} fill="none" strokeLinecap="round">
              <rect x={-2.3} y={-5} width={4.6} height={7.4} rx={2.3} />
              <path d="M -4.4 0.4 A 4.4 4.4 0 0 0 4.4 0.4" />
              <path d="M 0 4.8 L 0 7.2" />
              <path d="M -5.2 -6.2 L 5.2 7.4" strokeWidth={1.7} />
            </g>
          </g>
        )}

        {port.visible && (
          <g className="speaker-power-port" transform={featureTransform(port)}>
            <rect
              x={-portWidth / 2}
              y={-portHeight / 2}
              width={portWidth}
              height={portHeight}
              rx={portHeight * 0.35}
              fill="#0b0e12"
              stroke="#3b4654"
              strokeWidth={1}
            />
            <circle r={1.6} fill="#1f2833" />
          </g>
        )}
      </g>

      <path className="speaker-outline" stroke={theme.outline} d={body.d} />
    </g>
  );
};
