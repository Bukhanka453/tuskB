import { speakerCallouts, speakerDesign, speakerShape, surfacePoint } from './fixtures';
import type {
  Callout,
  CalloutDetail,
  CalloutSet,
  CalloutSource,
  ProductVariant,
} from './types';

export const productVariants: readonly ProductVariant[] = [
  { id: 'graphite', title: 'Графит' },
  { id: 'ivory', title: 'Слоновая кость' },
  { id: 'graphite-pro', title: 'Графит Pro' },
];

const proExtras: readonly Callout[] = [
  {
    id: 'aux-port',
    anchor: surfacePoint(speakerShape, 250, speakerDesign.powerPort.elevation + 6),
    text: 'Линейный вход 3,5 мм',
    priority: 15,
  },
  {
    id: 'nfc-pad',
    anchor: surfacePoint(speakerShape, 118, speakerDesign.lightRingElevation - 4),
    text: 'Площадка NFC',
    priority: 40,
  },
];

const variantCallouts = (variantId: string): readonly Callout[] => {
  if (variantId === 'graphite-pro') {
    return [...speakerCallouts, ...proExtras];
  }
  if (variantId === 'ivory') {
    return speakerCallouts.map(callout =>
      callout.id === 'fabric' ? { ...callout, text: 'Ткань цвета слоновой кости' } : callout,
    );
  }
  return speakerCallouts;
};

export interface SpeakerCalloutSourceOptions {
  /** Задержка ответа в миллисекундах. */
  latencyMs?: number;
  /** Варианты, для которых источник отвечает ошибкой. */
  failFor?: readonly string[];
  /** Задержка ответа подробностей; по умолчанию равна latencyMs. */
  detailLatencyMs?: number;
}

const detailBody = (variantId: string, calloutId: string): string => {
  const variant = productVariants.find(item => item.id === variantId)?.title ?? variantId;
  return `${calloutId} · ${variant}: материал, размеры и совместимость.`;
};

/**
 * Управляемый фейк каталога. Каждый вызов получает следующий `revision`,
 * поэтому два параллельных запроса за один и тот же вариант различимы.
 */
export const createSpeakerCalloutSource = (
  options: SpeakerCalloutSourceOptions = {},
): CalloutSource => {
  const latencyMs = options.latencyMs ?? 400;
  const failFor = new Set(options.failFor ?? []);
  let revision = 0;

  const detailLatencyMs = options.detailLatencyMs ?? latencyMs;

  return {
    loadDetail(variantId, calloutId, signal) {
      return new Promise<CalloutDetail>((resolve, reject) => {
        const abort = () => {
          clearTimeout(timer);
          reject(new DOMException('Запрос отменён', 'AbortError'));
        };

        const timer = setTimeout(() => {
          signal.removeEventListener('abort', abort);
          resolve({ variantId, calloutId, body: detailBody(variantId, calloutId) });
        }, detailLatencyMs);

        if (signal.aborted) {
          abort();
          return;
        }
        signal.addEventListener('abort', abort, { once: true });
      });
    },

    load(variantId, signal) {
      revision += 1;
      const issued = revision;

      return new Promise<CalloutSet>((resolve, reject) => {
        const abort = () => {
          clearTimeout(timer);
          reject(new DOMException('Запрос отменён', 'AbortError'));
        };

        const timer = setTimeout(() => {
          signal.removeEventListener('abort', abort);
          if (failFor.has(variantId)) {
            reject(new Error(`Не удалось загрузить аннотации варианта «${variantId}»`));
            return;
          }
          resolve({ variantId, revision: issued, callouts: variantCallouts(variantId) });
        }, latencyMs);

        if (signal.aborted) {
          abort();
          return;
        }
        signal.addEventListener('abort', abort, { once: true });
      });
    },
  };
};
