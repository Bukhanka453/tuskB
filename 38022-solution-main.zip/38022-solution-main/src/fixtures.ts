import type { Callout, ModelShape, Vec3 } from './types';

/** Корпус умной колонки: вытянутый по вертикали эллипсоид. */
export const speakerShape: ModelShape = {
  center: [0, 0, 0],
  radii: [1.6, 2.3, 1.6],
};

/**
 * Точка на поверхности корпуса.
 * `azimuth` — угол вокруг вертикальной оси, `elevation` — подъём над экватором (в градусах).
 */
export const surfacePoint = (
  shape: ModelShape,
  azimuth: number,
  elevation: number,
): Vec3 => {
  const a = (azimuth * Math.PI) / 180;
  const e = (elevation * Math.PI) / 180;
  return [
    shape.center[0] + shape.radii[0] * Math.cos(e) * Math.cos(a),
    shape.center[1] + shape.radii[1] * Math.sin(e),
    shape.center[2] + shape.radii[2] * Math.cos(e) * Math.sin(a),
  ];
};

/**
 * Конструкция корпуса: где на модели расположены её элементы.
 * Углы в градусах, линейные размеры — в мировых единицах корпуса.
 * Аннотации привязаны к этим же координатам, поэтому маркеры всегда
 * попадают точно на свои элементы.
 */
export const speakerDesign = {
  /** Стеклянная верхняя панель: часть корпуса выше этой высоты. */
  domeElevation: 55,
  /**
   * Плоское основание: корпус срезан ниже этой высоты, поэтому колонка
   * устойчиво стоит на ровной поверхности. Срез ниже всех аннотаций.
   */
  baseCutElevation: -55,
  /** Плинт основания: тёмная пластиковая полоса вдоль нижнего края. */
  baseBand: { fromElevation: -55, toElevation: -47 },
  /** Светодиодное кольцо на верхней панели (высота параллели). */
  lightRingElevation: 62,
  /** Отверстия массива микрофонов: общая высота и азимуты отверстий. */
  micArray: { elevation: 58, azimuths: [294, 300, 306], radius: 0.028 },
  /** Твитер на передней части корпуса. */
  tweeter: { azimuth: 0, elevation: 34, radius: 0.17 },
  /** Шов акустической ткани (меридиан и диапазон высот). */
  fabricSeam: { azimuth: 80, fromElevation: -44, toElevation: 52 },
  /** Кнопка отключения микрофона на верхней панели. */
  muteButton: { azimuth: 218, elevation: 58.5, radius: 0.12 },
  /** Разъём питания в нижней части корпуса, над плинтом. */
  powerPort: { azimuth: 262, elevation: -44, width: 0.24, height: 0.13 },
} as const;

export const speakerCallouts: readonly Callout[] = [
  {
    id: 'tweeter',
    anchor: surfacePoint(
      speakerShape,
      speakerDesign.tweeter.azimuth,
      speakerDesign.tweeter.elevation,
    ),
    text: 'Твитер 20 мм',
    priority: 80,
  },
  {
    id: 'light-ring',
    anchor: surfacePoint(speakerShape, 52, speakerDesign.lightRingElevation),
    text: 'Кольцо подсветки',
    priority: 60,
  },
  {
    id: 'mic-array',
    anchor: surfacePoint(speakerShape, 300, speakerDesign.micArray.elevation),
    text: 'Массив микрофонов',
    priority: 70,
  },
  {
    id: 'fabric',
    anchor: surfacePoint(speakerShape, speakerDesign.fabricSeam.azimuth, 4),
    text: 'Акустическая ткань',
    priority: 30,
  },
  {
    id: 'mute-button',
    anchor: surfacePoint(
      speakerShape,
      speakerDesign.muteButton.azimuth,
      speakerDesign.muteButton.elevation,
    ),
    text: 'Кнопка отключения микрофона',
    priority: 50,
  },
  {
    id: 'power-port',
    anchor: surfacePoint(
      speakerShape,
      speakerDesign.powerPort.azimuth,
      speakerDesign.powerPort.elevation,
    ),
    text: 'Разъём питания',
    priority: 20,
  },
];

export const initialCamera = { azimuth: 24, elevation: 12 };

export const defaultViewport = { width: 720, height: 520 };
