import type { Camera, ModelShape, ProjectedPoint, Size, Vec2, Vec3 } from './types';

/** Мировые единицы на один экранный пиксель. */
export const SCENE_SCALE = 90;

/** Высота камеры ограничена, чтобы базис экрана не вырождался у полюса. */
export const MAX_ELEVATION_DEG = 85;

export const LAYOUT = {
  /** Ширина подписи, когда реальная ширина текста недоступна. */
  labelWidth: 168,
  /** Внутренний отступ текста от края подписи с каждой стороны. */
  labelPaddingX: 10,
  /** Максимальная ширина подписи; более длинный текст ужимается. */
  maxLabelWidth: 236,
  /** Высота подписи в пикселях. */
  labelHeight: 28,
  /** Минимальный зазор между соседними подписями. */
  gap: 8,
  /** Горизонтальный вынос подписи от якоря. */
  leaderLength: 56,
  /** Отступ подписи от края вьюпорта. */
  margin: 12,
  /** На сколько пикселей якорь должен зайти за ось кадра, чтобы подпись сменила сторону. */
  sideSwitchMargin: 24,
} as const;

/** Плетение акустической ткани на корпусе. Шаги заданы по поверхности, в градусах. */
export const WEAVE = {
  /** Угловой шаг между соседними нитями основы (меридианами). */
  azimuthStep: 6,
  /** Угловой шаг между соседними нитями утка (параллелями). */
  elevationStep: 5,
  /** Ткань закрывает корпус между этими высотами. */
  minElevation: -70,
  maxElevation: 62,
  /** Сколько отрезков приходится на один угловой шаг при дискретизации. */
  segmentsPerStep: 2,
} as const;

const toRadians = (deg: number): number => (deg * Math.PI) / 180;

const dot = (a: Vec3, b: Vec3): number => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

const sub = (a: Vec3, b: Vec3): Vec3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];

const cross = (a: Vec3, b: Vec3): Vec3 => [
  a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2],
  a[0] * b[1] - a[1] * b[0],
];

const unit = (a: Vec3): Vec3 => {
  const length = Math.hypot(a[0], a[1], a[2]) || 1;
  return [a[0] / length, a[1] / length, a[2] / length];
};

export const clampElevation = (elevation: number): number =>
  Math.max(-MAX_ELEVATION_DEG, Math.min(MAX_ELEVATION_DEG, elevation));

/** Единичный вектор от центра сцены к камере на орбите. */
export const orbitDirection = (camera: Camera): Vec3 => {
  const azimuth = toRadians(camera.azimuth);
  const elevation = toRadians(clampElevation(camera.elevation));
  return [
    Math.cos(elevation) * Math.cos(azimuth),
    Math.sin(elevation),
    Math.cos(elevation) * Math.sin(azimuth),
  ];
};

/** Единичный вектор взгляда: из камеры в центр сцены. */
export const viewDirection = (camera: Camera): Vec3 => {
  const orbit = orbitDirection(camera);
  return [-orbit[0], -orbit[1], -orbit[2]];
};

/** Ортонормированный базис плоскости экрана: вправо и вверх. */
export const screenBasis = (camera: Camera): { right: Vec3; up: Vec3 } => {
  const direction = viewDirection(camera);
  const worldUp: Vec3 = [0, 1, 0];
  const right = unit(cross(direction, worldUp));
  const up = cross(right, direction);
  return { right, up };
};

/** Ортографическая проекция точки на экран. Меньшая глубина — ближе к наблюдателю. */
export const projectPoint = (point: Vec3, camera: Camera, viewport: Size): ProjectedPoint => {
  const { right, up } = screenBasis(camera);
  return {
    screen: {
      x: viewport.width / 2 + SCENE_SCALE * dot(point, right),
      y: viewport.height / 2 - SCENE_SCALE * dot(point, up),
    },
    depth: dot(point, viewDirection(camera)),
  };
};

/** Якорь виден, если нормаль поверхности в нём направлена навстречу наблюдателю. */
export const isAnchorVisible = (anchor: Vec3, shape: ModelShape, camera: Camera): boolean => {
  const offset = sub(anchor, shape.center);
  const normal = unit([
    offset[0] / (shape.radii[0] || 1),
    offset[1] / (shape.radii[1] || 1),
    offset[2] / (shape.radii[2] || 1),
  ]);
  return dot(normal, viewDirection(camera)) < 0;
};

/** Силуэт модели на экране: полуоси эллипса в пикселях. */
export const modelSilhouette = (
  shape: ModelShape,
  camera: Camera,
  viewport: Size,
): { center: Vec2; radiusX: number; radiusY: number } => {
  const { right, up } = screenBasis(camera);
  const projectRadius = (axis: Vec3): number =>
    Math.hypot(
      shape.radii[0] * axis[0],
      shape.radii[1] * axis[1],
      shape.radii[2] * axis[2],
    ) * SCENE_SCALE;

  const center = projectPoint(shape.center, camera, viewport).screen;
  return {
    center,
    radiusX: projectRadius(right),
    radiusY: projectRadius(up),
  };
};
