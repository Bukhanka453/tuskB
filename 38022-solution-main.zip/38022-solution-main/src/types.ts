export type Vec3 = readonly [number, number, number];

export interface Vec2 {
  x: number;
  y: number;
}

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Size {
  width: number;
  height: number;
}

/** Орбитальная камера: азимут и высота в градусах. */
export interface Camera {
  azimuth: number;
  elevation: number;
}

/** Корпус товара, аппроксимированный эллипсоидом. */
export interface ModelShape {
  center: Vec3;
  radii: Vec3;
}

/** Аннотация, привязанная к точке на поверхности модели. */
export interface Callout {
  id: string;
  anchor: Vec3;
  text: string;
  /** Больше — раскладывается ближе к желаемой позиции. */
  priority: number;
}

export type CalloutSide = 'left' | 'right';

/** Результат раскладки одной выноски. */
export interface PlacedCallout {
  id: string;
  side: CalloutSide;
  /** Якорь ушёл на дальнюю сторону модели — выноска не рисуется. */
  hidden: boolean;
  /** Выноска закреплена покупателем: подпись остаётся на сцене даже при hidden. */
  pinned: boolean;
  anchorScreen: Vec2;
  depth: number;
  labelBox: Rect;
}

export interface ProjectedPoint {
  screen: Vec2;
  depth: number;
}

/** Вариант товара: цвет корпуса и комплектация. */
export interface ProductVariant {
  id: string;
  title: string;
}

/** Набор аннотаций, полученный от сервера для конкретного варианта. */
export interface CalloutSet {
  variantId: string;
  revision: number;
  callouts: readonly Callout[];
}

/** Источник аннотаций. Один вызов — один сетевой запрос. */
export interface CalloutSource {
  load(variantId: string, signal: AbortSignal): Promise<CalloutSet>;
  /** Один вызов — один сетевой запрос подробностей. */
  loadDetail(variantId: string, calloutId: string, signal: AbortSignal): Promise<CalloutDetail>;
}

export type CalloutPhase = 'loading' | 'ready' | 'error';

/**
 * Состояние аннотаций, общее для всех поверхностей карточки.
 *
 * `selectedVariantId` — что выбрал покупатель прямо сейчас.
 * `shownVariantId` — к какому варианту относится набор, который сейчас на экране.
 * Во время загрузки они различаются: на сцене остаётся прежний набор.
 */
export interface CalloutState {
  selectedVariantId: string;
  shownVariantId: string | null;
  phase: CalloutPhase;
  revision: number;
  callouts: readonly Callout[];
  error: string | null;
  /** Закреплённые покупателем выноски (id). */
  pinnedIds: readonly string[];
  /** Раскрытая аннотация и её подробности. */
  detail: DetailState;
}

/** Подробности аннотации: приходят отдельным запросом на пару «вариант + аннотация». */
export interface CalloutDetail {
  variantId: string;
  calloutId: string;
  body: string;
}

export type DetailPhase = 'idle' | 'loading' | 'ready' | 'error';

/** Слот раскрытой аннотации. Раскрыта не более одной. */
export interface DetailState {
  calloutId: string | null;
  phase: DetailPhase;
  body: string | null;
}

export interface CalloutController {
  getState(): CalloutState;
  subscribe(listener: () => void): () => void;
  selectVariant(variantId: string): void;
  /** Закрепить или снять закрепление выноски. */
  togglePin(calloutId: string): void;
  /** Раскрыть подробности аннотации или свернуть их. */
  toggleDetail(calloutId: string): void;
  retry(): void;
  dispose(): void;
}

/** Запись единого указателя аннотаций карточки. */
export interface CalloutIndexEntry {
  id: string;
  number: number;
  text: string;
  /** Идентификаторы сцен, где выноска сейчас видна. */
  visibleOn: readonly string[];
  /** Выноска закреплена покупателем. */
  pinned: boolean;
}

/** Раскладки всех сцен карточки: ключ — идентификатор сцены. */
export type SurfaceLayouts = Readonly<Record<string, readonly PlacedCallout[]>>;

/**
 * Измеренные ширины текста подписей по id выноски (px).
 * null — реальные ширины недоступны (среда без метрик текста).
 */
export type LabelWidths = ReadonlyMap<string, number> | null;
