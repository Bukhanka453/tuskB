import { surfacePoint } from './fixtures';
import { WEAVE, isAnchorVisible, projectPoint } from './projection';
import type { Camera, ModelShape, Size, Vec2, Vec3 } from './types';

export type WeaveLineKind = 'meridian' | 'parallel';

/** Одна нить плетения, спроецированная на экран. */
export interface WeaveLine {
  kind: WeaveLineKind;
  /** Параметр нити в градусах: азимут меридиана либо высота параллели. */
  at: number;
  /** Полилиния в экранных координатах сцены. */
  points: readonly Vec2[];
}

/** Сколько итераций уточняют точку, где нить уходит за терминатор. */
const BOUNDARY_REFINEMENTS = 20;

/**
 * Видимые куски одной нити.
 *
 * Нить задана параметрически на поверхности корпуса и сэмплируется равномерно
 * по параметру. Граница между видимым и скрытым куском уточняется бисекцией
 * **по параметру**, поэтому крайняя точка остаётся на поверхности: нить
 * обрывается ровно на силуэте, а не на ближайшем узле сетки сэмплов.
 *
 * `closed` — нить замкнута (полный оборот по азимуту). Тогда куски у начала и
 * конца диапазона сшиваются: разрез на нуле азимута не должен выглядеть
 * разрывом ткани.
 */
const traceThread = (
  kind: WeaveLineKind,
  at: number,
  pointAt: (t: number) => Vec3,
  from: number,
  to: number,
  steps: number,
  closed: boolean,
  shape: ModelShape,
  camera: Camera,
  viewport: Size,
): WeaveLine[] => {
  const visibleAt = (t: number): boolean => isAnchorVisible(pointAt(t), shape, camera);
  const screenAt = (t: number): Vec2 => projectPoint(pointAt(t), camera, viewport).screen;

  /** Параметр точки, где нить пересекает силуэт; возвращается видимая сторона. */
  const boundary = (visible: number, hidden: number): number => {
    let lo = visible;
    let hi = hidden;
    for (let i = 0; i < BOUNDARY_REFINEMENTS; i += 1) {
      const mid = (lo + hi) / 2;
      if (visibleAt(mid)) lo = mid;
      else hi = mid;
    }
    return lo;
  };

  const runs: Vec2[][] = [];
  let run: Vec2[] | null = null;
  let previous: { t: number; visible: boolean } | null = null;

  for (let step = 0; step <= steps; step += 1) {
    const t = from + ((to - from) * step) / steps;
    const visible = visibleAt(t);

    if (visible) {
      if (!run) {
        run = [];
        // Нить входит в видимую зону: начинаем ровно с силуэта.
        if (previous && !previous.visible) run.push(screenAt(boundary(t, previous.t)));
      }
      run.push(screenAt(t));
    } else if (run) {
      // Нить уходит за корпус: доводим её до силуэта и закрываем кусок.
      if (previous?.visible) run.push(screenAt(boundary(previous.t, t)));
      runs.push(run);
      run = null;
    }

    previous = { t, visible };
  }

  if (run) runs.push(run);

  // Замкнутая нить: куски по обе стороны разреза — на самом деле один.
  if (closed && runs.length > 1 && visibleAt(from) && visibleAt(to)) {
    const first = runs.shift() as Vec2[];
    runs[runs.length - 1] = [...runs[runs.length - 1], ...first];
  }

  return runs.filter(points => points.length >= 2).map(points => ({ kind, at, points }));
};

/**
 * Плетение акустической ткани на корпусе. Нити заданы по поверхности, а не по
 * экрану: шаг постоянен в угловой мере, поэтому при повороте камеры ткань едет
 * вместе с корпусом и сгущается к силуэту.
 */
export const buildWeave = (
  shape: ModelShape,
  camera: Camera,
  viewport: Size,
): readonly WeaveLine[] => {
  const { azimuthStep, elevationStep, minElevation, maxElevation, segmentsPerStep } = WEAVE;
  const lines: WeaveLine[] = [];

  // Нити основы: постоянный азимут, от нижней кромки ткани к верхней.
  const warpSteps = Math.round(((maxElevation - minElevation) / elevationStep) * segmentsPerStep);
  for (let azimuth = 0; azimuth < 360; azimuth += azimuthStep) {
    lines.push(
      ...traceThread(
        'meridian',
        azimuth,
        elevation => surfacePoint(shape, azimuth, elevation),
        minElevation,
        maxElevation,
        warpSteps,
        false,
        shape,
        camera,
        viewport,
      ),
    );
  }

  // Нити утка: постоянная высота, замкнутый оборот вокруг корпуса.
  const weftSteps = Math.round((360 / azimuthStep) * segmentsPerStep);
  const rings = Math.floor((maxElevation - minElevation) / elevationStep);
  for (let ring = 0; ring <= rings; ring += 1) {
    const elevation = minElevation + ring * elevationStep;
    lines.push(
      ...traceThread(
        'parallel',
        elevation,
        azimuth => surfacePoint(shape, azimuth, elevation),
        0,
        360,
        weftSteps,
        true,
        shape,
        camera,
        viewport,
      ),
    );
  }

  return lines;
};
