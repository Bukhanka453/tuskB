export { stabilizeScreenshot } from './screenshot';
