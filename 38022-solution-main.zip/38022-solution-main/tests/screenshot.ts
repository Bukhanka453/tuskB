import type { Page } from '@playwright/test';

export async function stabilizeScreenshot(page: Pick<Page, 'evaluate'>) {
  await page.evaluate(async () => {
    await document.fonts?.ready;
    await new Promise<void>(resolve => requestAnimationFrame(() => resolve()));
    await new Promise<void>(resolve => requestAnimationFrame(() => resolve()));
  });
}
