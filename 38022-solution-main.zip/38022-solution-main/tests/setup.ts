import '@testing-library/jest-dom/vitest';

// jsdom doesn't implement URL.createObjectURL/revokeObjectURL
if (typeof URL.createObjectURL !== 'function') {
  URL.createObjectURL = () => 'blob:mock-stub';
}
if (typeof URL.revokeObjectURL !== 'function') {
  URL.revokeObjectURL = () => {};
}

// jsdom doesn't implement navigator.sendBeacon
if (typeof navigator.sendBeacon !== 'function') {
  Object.defineProperty(navigator, 'sendBeacon', {
    value: () => true,
    writable: true,
    configurable: true,
  });
}
