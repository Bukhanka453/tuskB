import { defineConfig, mergeConfig } from 'vitest/config';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const semanticVitestConfig = defineConfig({
  esbuild: { jsx: 'automatic' },
  test: {
    environment: 'jsdom',
    globals: true,
    include: ['tests/**/*.test.{ts,tsx}'],
    testTimeout: 30_000,
  },
});

export default mergeConfig(semanticVitestConfig, defineConfig({
  resolve: {
    alias: {
      '@target': resolve(__dirname, 'src'),
    },
  },
  test: {
    setupFiles: [resolve(__dirname, 'tests/setup.ts')],
  },
}));
