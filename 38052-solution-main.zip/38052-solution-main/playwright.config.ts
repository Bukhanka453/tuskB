import { defineConfig } from '@playwright/test';

const port = Number(process.env.PW_PORT ?? 4173);

export default defineConfig({
  testDir: './tests',
  testMatch: ['**/*.e2e.ts'],
  reporter: process.env.PW_JSON_OUTPUT
    ? [['line'], ['json', { outputFile: process.env.PW_JSON_OUTPUT }]]
    : 'line',
  use: {
    baseURL: `http://127.0.0.1:${port}`,
    viewport: { width: 1280, height: 720 },
    locale: 'ru-RU',
    timezoneId: 'UTC',
    colorScheme: 'light',
  },
  webServer: {
    command: 'npm run dev:e2e:target',
    port,
    reuseExistingServer: !process.env.CI,
    timeout: 120_000,
  },
});

