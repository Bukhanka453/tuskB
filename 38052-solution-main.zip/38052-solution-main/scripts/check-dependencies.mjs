import { readFileSync, readdirSync, statSync } from 'node:fs';
import { extname, join, relative, resolve } from 'node:path';
import ts from 'typescript';

const sourceRoot = resolve('src');
const sourceExtensions = new Set(['.ts', '.tsx']);
const allowedPackages = [
  'react',
  'react-dom',
  'ajv',
  'ajv-formats',
  'radix-ui',
  'lucide-react',
  'class-variance-authority',
  'clsx',
  'tailwind-merge',
  '@dnd-kit/core',
  '@dnd-kit/sortable',
  '@dnd-kit/utilities',
  'recharts',
];

const isLocalSpecifier = (specifier) =>
  specifier.startsWith('.') || specifier.startsWith('@/');

const isAllowedPackage = (specifier) =>
  allowedPackages.some((name) => specifier === name || specifier.startsWith(`${name}/`));

const sourceFiles = (directory) => readdirSync(directory).flatMap((name) => {
  const path = join(directory, name);
  if (statSync(path).isDirectory()) return sourceFiles(path);
  return sourceExtensions.has(extname(path)) ? [path] : [];
});

const violations = [];

for (const file of sourceFiles(sourceRoot)) {
  const source = ts.createSourceFile(
    file,
    readFileSync(file, 'utf8'),
    ts.ScriptTarget.Latest,
    true,
    file.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS,
  );

  const inspect = (node) => {
    let specifier;

    if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier) {
      specifier = node.moduleSpecifier.text;
    } else if (ts.isCallExpression(node) && node.arguments.length === 1) {
      const [argument] = node.arguments;
      const isDynamicImport = node.expression.kind === ts.SyntaxKind.ImportKeyword;
      const isRequire = ts.isIdentifier(node.expression) && node.expression.text === 'require';
      if ((isDynamicImport || isRequire) && ts.isStringLiteral(argument)) specifier = argument.text;
    }

    if (specifier && !isLocalSpecifier(specifier) && !isAllowedPackage(specifier)) {
      const position = source.getLineAndCharacterOfPosition(node.getStart(source));
      violations.push(`${relative(process.cwd(), file)}:${position.line + 1}: ${specifier}`);
    }

    ts.forEachChild(node, inspect);
  };

  inspect(source);
}

if (violations.length > 0) {
  console.error('Обнаружены импорты зависимостей вне allowlist:');
  console.error(violations.join('\n'));
  process.exit(1);
}
