import type { JsonSchemaFormProps } from './types';

/**
 * Реализуйте универсальный renderer JSON Schema здесь.
 * Вспомогательные компоненты и функции можно выносить в отдельные файлы в src/.
 */
export function JsonSchemaForm(_props: JsonSchemaFormProps) {
  return (
    <section aria-label="JSON Schema Form">
      <p>Компонент формы ещё не реализован.</p>
    </section>
  );
}

export type { JsonSchemaCustomViewProps, JsonSchemaCustomViews, JsonSchemaFormProps } from './types';
