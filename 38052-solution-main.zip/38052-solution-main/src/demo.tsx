import { useState } from 'react';
import { JsonSchemaForm } from './JsonSchemaForm';
import type { FormData, JsonSchema } from './types';

const schema: JsonSchema = {
  type: 'object',
  title: 'Профиль участника',
  description: 'Одна схема используется для создания, редактирования и просмотра.',
  required: ['name', 'email'],
  properties: {
    name: { type: 'string', title: 'Имя', minLength: 2, 'x-ui': { placeholder: 'Анна' } },
    email: { type: 'string', title: 'Email', format: 'email' },
    experience: { type: 'integer', title: 'Опыт во frontend', minimum: 0, default: 0 },
    available: { type: 'boolean', title: 'Готов приступить', default: false },
    bio: { type: 'string', title: 'О себе', maxLength: 300, 'x-ui': { widget: 'textarea' } },
    skills: { type: 'array', title: 'Навыки', maxItems: 5, items: { type: 'string', title: 'Навык' } },
  },
};

const existingValue: FormData = {
  name: 'Анна Смирнова',
  email: 'anna@example.com',
  experience: 2,
  available: true,
  bio: 'Frontend-разработчик',
  skills: ['React', 'TypeScript'],
};

export function Demo() {
  const params = new URLSearchParams(window.location.search);
  const requestedMode = params.get('mode');
  const mode = requestedMode === 'edit' || requestedMode === 'view' ? requestedMode : 'create';
  const [submitted, setSubmitted] = useState<FormData>();

  return (
    <main className="mx-auto grid min-h-screen max-w-2xl gap-6 px-4 py-10">
      <JsonSchemaForm
        schema={schema}
        data={mode === 'create' ? undefined : existingValue}
        readOnly={mode === 'view'}
        onSubmit={setSubmitted}
      />
      {submitted && <output aria-label="Отправленные данные" className="rounded-xl border bg-muted p-4 text-sm"><pre>{JSON.stringify(submitted, null, 2)}</pre></output>}
    </main>
  );
}
