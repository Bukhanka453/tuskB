import type { ComponentType, ReactNode } from 'react';

export type JsonPrimitive = string | number | boolean | null;

export type JsonValue =
  | JsonPrimitive
  | JsonValue[]
  | { [key: string]: JsonValue };

export interface JsonSchemaUiOptions {
  widget?: 'input' | 'textarea' | 'select' | 'radio' | 'checkbox' | string;
  view?: string;
  placeholder?: string;
  enumLabels?: Record<string, string>;
  enumOptions?: Record<string, JsonSchemaEnumOption>;
}

export type JsonSchemaEnumColor = 'gray' | 'blue' | 'green' | 'amber' | 'red' | 'violet' | 'cyan';
export type JsonSchemaEnumIcon = 'circle' | 'clock' | 'check-circle' | 'x-circle' | 'alert' | 'star' | 'tag' | 'bug' | 'zap';

export interface JsonSchemaEnumOption {
  label?: string;
  color?: JsonSchemaEnumColor;
  icon?: JsonSchemaEnumIcon;
}

export interface JsonSchema {
  $schema?: 'http://json-schema.org/draft-07/schema#' | string;
  $id?: string;
  title?: string;
  description?: string;
  type?: 'object' | 'array' | 'string' | 'number' | 'integer' | 'boolean' | 'null';
  properties?: Record<string, JsonSchema>;
  required?: string[];
  items?: JsonSchema;
  enum?: JsonValue[];
  const?: JsonValue;
  default?: JsonValue;
  format?: string;
  contentEncoding?: string;
  contentMediaType?: string;
  minimum?: number;
  maximum?: number;
  exclusiveMinimum?: number;
  exclusiveMaximum?: number;
  multipleOf?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  minItems?: number;
  maxItems?: number;
  uniqueItems?: boolean;
  minProperties?: number;
  maxProperties?: number;
  additionalProperties?: boolean;
  readOnly?: boolean;
  writeOnly?: boolean;
  'x-ui'?: JsonSchemaUiOptions;
}

export type FormData = Record<string, JsonValue>;

export interface ValidationError {
  path: string;
  keyword: string;
  message: string;
}

export type JsonSchemaPath = Array<string | number>;

export interface JsonSchemaCustomViewProps {
  schema: JsonSchema;
  value: JsonValue | undefined;
  path: JsonSchemaPath;
  disabled: boolean;
  readOnly: boolean;
  onChange: (value: JsonValue | undefined) => void;
  onBlur: () => void;
  renderDefault: () => ReactNode;
}

export type JsonSchemaCustomViews = Record<string, ComponentType<JsonSchemaCustomViewProps>>;

export interface JsonSchemaFormProps {
  schema: JsonSchema;
  data?: FormData;
  disabled?: boolean;
  readOnly?: boolean;
  idPrefix?: string;
  customViews?: JsonSchemaCustomViews;
  onChange?: (value: FormData) => void;
  onSubmit?: (value: FormData) => void;
  onValidationChange?: (errors: ValidationError[]) => void;
}
