import { fireEvent, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import { JsonSchemaForm, type JsonSchemaCustomViewProps } from '@target/JsonSchemaForm';
import type { JsonSchema } from '@target/types';

describe('JSON Schema Form', () => {
  describe('Уровень 1 — Базовые типы', () => describe('Типовые границы', () => {
    it('fills only missing nested defaults', () => {
      const onSubmit = vi.fn();
      render(<JsonSchemaForm data={{ settings: { enabled: false, retries: 0 } }} schema={{
        type: 'object', properties: { settings: { type: 'object', properties: {
          enabled: { type: 'boolean', title: 'Включено', default: true },
          retries: { type: 'integer', title: 'Повторы', default: 3 },
          label: { type: 'string', title: 'Метка', default: 'main' },
        } } },
      }} onSubmit={onSubmit} />);

      screen.getByRole('button', { name: 'Отправить' }).click();
      expect(onSubmit).toHaveBeenCalledWith({ settings: { enabled: false, retries: 0, label: 'main' } });
    });
  }));

  describe('Уровень 2 — Вложенные данные и массивы', () => {
    describe('Объекты и пути', () => {
      it('builds nested JSON values without mutating sibling branches', () => {
        const onChange = vi.fn();
        const profile = { name: 'Анна' };
        render(<JsonSchemaForm data={{ profile, score: 1 }} schema={{ type: 'object', properties: {
          profile: { type: 'object', properties: { name: { type: 'string', title: 'Имя' } } },
          score: { type: 'number', title: 'Оценка' },
        } }} onChange={onChange} />);

        fireEvent.change(screen.getByRole('spinbutton', { name: 'Оценка' }), { target: { value: '2' } });
        expect(onChange.mock.lastCall?.[0]).toEqual({ profile, score: 2 });
        expect(onChange.mock.lastCall?.[0].profile).toBe(profile);
      });

    });
    describe('Вложенные массивы', () => {
      it('updates an item inside a nested array without changing siblings', () => {
        const onChange = vi.fn();
        const untouched = { score: 2 };
        render(<JsonSchemaForm data={{ rows: [{ score: 1 }, untouched] }} schema={{ type: 'object', properties: {
          rows: { type: 'array', title: 'Строки', items: { type: 'object', properties: {
            score: { type: 'number', title: 'Баллы' },
          } } },
        } }} onChange={onChange} />);

        fireEvent.change(screen.getAllByRole('spinbutton', { name: 'Баллы' })[0], { target: { value: '5' } });
        expect(onChange.mock.lastCall?.[0]).toEqual({ rows: [{ score: 5 }, { score: 2 }] });
        expect(onChange.mock.lastCall?.[0].rows[1]).toBe(untouched);
      });

      it('keeps array item identity when a neighbor is removed', async () => {
        const user = userEvent.setup();
        render(<JsonSchemaForm data={{ tags: ['first', 'second'] }} schema={{ type: 'object', properties: {
          tags: { type: 'array', title: 'Теги', items: { type: 'string', title: 'Тег' } },
        } }} />);

        const before = document.querySelectorAll<HTMLElement>('[data-array-item-key]');
        const secondKey = before[1].dataset.arrayItemKey;
        await user.click(screen.getByRole('button', { name: 'Удалить элемент 1' }));
        const after = document.querySelectorAll<HTMLElement>('[data-array-item-key]');
        expect(after[0].dataset.arrayItemKey).toBe(secondKey);
        expect(after[0]).toBe(before[1]);
      });
    });
  });

  describe('Уровень 2 — Режимы формы', () => describe('Unit-проекции', () => {
    it('renders enum badges and returns typed multi-select values', async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<JsonSchemaForm data={{ priority: 1, labels: ['bug'] }} schema={{ type: 'object', properties: {
        priority: { type: 'integer', title: 'Приоритет', enum: [1, 2], 'x-ui': { enumOptions: {
          '1': { label: 'Низкий', color: 'gray', icon: 'circle' },
          '2': { label: 'Высокий', color: 'red', icon: 'alert' },
        } } },
        labels: { type: 'array', title: 'Метки', uniqueItems: true, items: { type: 'string', enum: ['bug', 'feature'], 'x-ui': { enumOptions: {
          bug: { label: 'Ошибка', color: 'red', icon: 'bug' }, feature: { label: 'Фича', color: 'green', icon: 'zap' },
        } } } },
      } }} onChange={onChange} />);

      await user.click(screen.getByRole('combobox', { name: 'Приоритет' }));
      await user.click(screen.getByRole('option', { name: 'Высокий' }));
      expect(onChange).toHaveBeenLastCalledWith({ priority: 2, labels: ['bug'] });
      await user.click(screen.getByRole('button', { name: 'Фича' }));
      expect(onChange).toHaveBeenLastCalledWith({ priority: 2, labels: ['bug', 'feature'] });
    });
  }));

  describe('Уровень 3 — Качество реализации', () => {
    describe('Локальные обновления', () => {
    it('keeps an unrelated DOM control and focus stable after a leaf update', () => {
      const properties = Object.fromEntries(Array.from({ length: 120 }, (_, i) => [`field${i}`, { type: 'string' as const, title: `Поле ${i}` }]));
      render(<JsonSchemaForm schema={{ type: 'object', properties }} data={{}} />);
      const stable = screen.getByRole('textbox', { name: 'Поле 119' });
      stable.focus();
      fireEvent.change(screen.getByRole('textbox', { name: 'Поле 0' }), { target: { value: 'updated' } });
      expect(screen.getByRole('textbox', { name: 'Поле 119' })).toBe(stable);
      expect(document.activeElement).toBe(stable);
    });

    });
    describe('Lifecycle ошибок', () => {
      it('does not repeat an equivalent validation callback', () => {
      const onValidationChange = vi.fn();
      const schema: JsonSchema = { type: 'object', required: ['name'], properties: { name: { type: 'string', title: 'Имя' } } };
      const { rerender } = render(<JsonSchemaForm schema={schema} onValidationChange={onValidationChange} />);
      expect(onValidationChange).toHaveBeenCalledTimes(1);
      rerender(<JsonSchemaForm schema={schema} onValidationChange={onValidationChange} disabled />);
      rerender(<JsonSchemaForm schema={schema} onValidationChange={onValidationChange} />);
      expect(onValidationChange).toHaveBeenCalledTimes(1);
      });
    });
  });

  describe('Уровень 4 — Публичный API', () => describe('Custom views', () => {
    const schema: JsonSchema = { type: 'object', properties: {
      title: { type: 'string', title: 'Название' },
      series: { type: 'array', title: 'Ряд', items: { type: 'number', title: 'Точка' }, 'x-ui': { view: 'chart' } },
    } };

    it('selects a registered custom view at a nested schema node', () => {
      const Chart = () => <section data-testid="injected-view" />;
      render(<JsonSchemaForm schema={schema} data={{ title: 'A', series: [1, 2] }} customViews={{ chart: Chart }} />);
      expect(screen.getByTestId('injected-view')).toBeInTheDocument();
    });

    it('passes schema value path disabled and readOnly to a custom view', () => {
      const Chart = (props: JsonSchemaCustomViewProps) => <output data-testid="view-props">{JSON.stringify({ value: props.value, path: props.path, title: props.schema.title, disabled: props.disabled, readOnly: props.readOnly })}</output>;
      render(<JsonSchemaForm schema={schema} data={{ title: 'A', series: [1, 2] }} customViews={{ chart: Chart }} disabled />);
      expect(screen.getByTestId('view-props')).toHaveTextContent(JSON.stringify({ value: [1, 2], path: ['series'], title: 'Ряд', disabled: true, readOnly: false }));
    });

    it('custom view onChange updates only its branch and preserves sibling references', async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      const sibling = { keep: true };
      const branchSchema: JsonSchema = { ...schema, properties: { ...schema.properties, sibling: { type: 'object' } } };
      const Chart = ({ onChange }: JsonSchemaCustomViewProps) => <button type="button" onClick={() => onChange([8, 5, 3])}>Заменить ряд</button>;
      render(<JsonSchemaForm schema={branchSchema} data={{ title: 'A', series: [1, 2], sibling }} customViews={{ chart: Chart }} onChange={onChange} />);
      await user.click(screen.getByRole('button', { name: 'Заменить ряд' }));
      expect(onChange.mock.lastCall?.[0]).toEqual({ title: 'A', series: [8, 5, 3], sibling });
      expect(onChange.mock.lastCall?.[0].sibling).toBe(sibling);
    });

    it('custom view onBlur participates in the field validation lifecycle', async () => {
      const user = userEvent.setup();
      const BlurView = ({ onBlur, renderDefault }: JsonSchemaCustomViewProps) => <section><button type="button" onClick={onBlur}>Посетить ряд</button>{renderDefault()}</section>;
      const invalidSchema: JsonSchema = { type: 'object', properties: { series: { type: 'string', title: 'Ряд', minLength: 3, 'x-ui': { view: 'chart' } } } };
      render(<JsonSchemaForm schema={invalidSchema} data={{ series: 'x' }} customViews={{ chart: BlurView }} />);
      expect(screen.queryByRole('alert')).not.toBeInTheDocument();
      await user.click(screen.getByRole('button', { name: 'Посетить ряд' }));
      expect(screen.getByRole('alert')).toBeInTheDocument();
    });

    it('renderDefault renders the standard editor and remains interactive', async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      const Chart = ({ renderDefault }: JsonSchemaCustomViewProps) => <section>{renderDefault()}</section>;
      render(<JsonSchemaForm schema={schema} data={{ title: 'A', series: [1, 2] }} customViews={{ chart: Chart }} onChange={onChange} />);
      const points = screen.getAllByRole('spinbutton', { name: 'Точка' });
      await user.clear(points[0]);
      await user.type(points[0], '7');
      expect(onChange.mock.lastCall?.[0]).toEqual({ title: 'A', series: [7, 2] });
    });
  }));
});
