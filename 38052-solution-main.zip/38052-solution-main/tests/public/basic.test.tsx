import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import { JsonSchemaForm } from '@target/JsonSchemaForm';

describe('JSON Schema Form', () => {
  describe('Уровень 1 — Базовые типы', () => {
    describe('Публичный контракт', () => {
      it('renders a string property and reports its value', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();

    render(
      <JsonSchemaForm
        schema={{
          type: 'object',
          properties: { name: { type: 'string', title: 'Имя' } },
        }}
        onChange={onChange}
      />,
    );

    await user.type(screen.getByRole('textbox', { name: 'Имя' }), 'Анна');

    expect(onChange).toHaveBeenLastCalledWith({ name: 'Анна' });
      });
    });
  });
});
