import { expect, test } from '@playwright/test';

test.describe('JSON Schema Form', () => {
test.describe('Уровень 1 — Валидация и submit', () => test.describe('Blur и submit', () => {
test('create mode validates and submits typed data', async ({ page }) => {
  await page.goto('/?mode=create');

  await page.getByLabel('Имя *').fill('Анна');
  await page.getByLabel('Email *').fill('invalid');
  await page.getByLabel('Email *').blur();
  await expect(page.getByLabel('Email *')).toHaveAttribute('aria-invalid', 'true');

  await page.getByLabel('Email *').fill('anna@example.com');
  await page.getByLabel('Опыт во frontend').fill('2');
  await page.getByLabel('Готов приступить').click();
  await page.getByRole('button', { name: 'Добавить' }).click();
  await page.getByLabel('Навык').fill('React');
  await page.getByRole('button', { name: 'Отправить' }).click();

  const output = page.getByRole('status', { name: 'Отправленные данные' }).or(page.locator('output[aria-label="Отправленные данные"]'));
  await expect(output).toContainText('"experience": 2');
  await expect(output).toContainText('"available": true');
  await expect(output).toContainText('"React"');
});
}));

test.describe('Уровень 2 — Режимы формы', () => test.describe('Browser-проекции', () => {
test('view mode has no editable controls', async ({ page }) => {
  await page.goto('/?mode=view');
  await expect(page.getByRole('article', { name: 'Профиль участника' })).toBeVisible();
  await expect(page.getByText('Анна Смирнова')).toBeVisible();
  await expect(page.locator('input, textarea, select')).toHaveCount(0);
  await expect(page.getByRole('button')).toHaveCount(0);
});
}));
});
