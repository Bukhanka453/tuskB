import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import { JsonSchemaForm } from '@target/JsonSchemaForm';

describe('JSON Schema Form', () => {
  describe('Уровень 1 — Базовые типы', () => {
    describe('Публичный контракт', () => {
      it('returns numbers and booleans as JSON values', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();

    render(
      <JsonSchemaForm
        schema={{
          type: 'object',
          properties: {
            age: { type: 'integer', title: 'Возраст' },
            subscribed: { type: 'boolean', title: 'Подписка' },
          },
        }}
        onChange={onChange}
      />,
    );

    await user.type(screen.getByRole('spinbutton', { name: 'Возраст' }), '21');
    expect(onChange.mock.lastCall?.[0].age).toBe(21);

    await user.click(screen.getByRole('checkbox', { name: 'Подписка' }));
    expect(onChange.mock.lastCall?.[0].subscribed).toBe(true);
      });
    });
  });

  describe('Уровень 1 — Валидация и submit', () => {
    describe('Blur и submit', () => {
      it('shows a visited field error and blocks invalid submit', async () => {
    const user = userEvent.setup();
    const onSubmit = vi.fn();

    render(
      <JsonSchemaForm
        schema={{
          type: 'object',
          required: ['name'],
          properties: { name: { type: 'string', title: 'Имя', minLength: 3 } },
        }}
        onSubmit={onSubmit}
      />,
    );

    const name = screen.getByRole('textbox', { name: /Имя/ });
    await user.type(name, 'Я');
    expect(name).toHaveAttribute('aria-invalid', 'false');
    await user.tab();
    expect(name).toHaveAttribute('aria-invalid', 'true');

    await user.click(screen.getByRole('button', { name: 'Отправить' }));
    expect(onSubmit).not.toHaveBeenCalled();
      });
    });
  });

  describe('Уровень 2 — Режимы формы', () => {
    describe('Unit-проекции', () => {
      it('renders view mode without editable controls', () => {
    render(
      <JsonSchemaForm
        readOnly
        schema={{
          type: 'object',
          title: 'Карточка',
          properties: {
            name: { type: 'string', title: 'Имя' },
            active: { type: 'boolean', title: 'Активен' },
          },
        }}
        data={{ name: 'Анна', active: true }}
      />,
    );

    expect(screen.getByRole('article', { name: 'Карточка' })).toBeInTheDocument();
    expect(screen.getByText('Анна')).toBeInTheDocument();
    expect(screen.getByText('Да')).toBeInTheDocument();
    expect(screen.queryByRole('textbox')).not.toBeInTheDocument();
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
      });
    });
  });
});
